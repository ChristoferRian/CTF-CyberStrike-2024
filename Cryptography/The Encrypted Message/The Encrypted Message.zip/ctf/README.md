# Capture The Flag Challenge\n\nIn this challenge, you need to decrypt the hidden message to find the flag. Use the key provided in the key.txt file and your skills to decode the message.
